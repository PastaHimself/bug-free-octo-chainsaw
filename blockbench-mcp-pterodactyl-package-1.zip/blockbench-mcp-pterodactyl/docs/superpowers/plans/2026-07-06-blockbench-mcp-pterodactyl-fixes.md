# Blockbench MCP Pterodactyl Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair the generated Pterodactyl package so it accurately runs a noVNC Blockbench desktop session, avoids misleading MCP readiness/configuration behavior, and is safer to deploy.

**Architecture:** The Pterodactyl egg starts a container image that runs Xvfb, Fluxbox, x11vnc, websockify/noVNC, and Blockbench desktop. The Blockbench MCP endpoint is created only by the Blockbench desktop plugin after the user loads `/home/container/mcp-plugin/mcp.js` inside Blockbench.

**Tech Stack:** Pterodactyl egg JSON, Ubuntu 22.04 Docker image, Bash startup script, GitHub Actions, noVNC, x11vnc, Xvfb, Blockbench desktop.

## Global Constraints

- Preserve the package layout: `pterodactyl/`, `docker/`, `.github/workflows/`, `client-configs/`, and `README.md`.
- Keep the default MCP URL as `http://localhost:3000/bb-mcp`.
- Do not claim MCP is ready until the plugin is loaded inside Blockbench.
- Do not pass the VNC password to `x11vnc` through the process argument list.
- Keep GHCR image name lowercase: `ghcr.io/pastahimself/blockbench-mcp-pterodactyl`.

---

### Task 1: Fix workflow image naming

**Files:**
- Modify: `.github/workflows/publish-ghcr.yml`

**Interfaces:**
- Consumes: GitHub Actions `GITHUB_REPOSITORY_OWNER` environment variable.
- Produces: Lowercase `IMAGE_NAME` in `$GITHUB_ENV`.

- [ ] Add a step before Docker build:

```yaml
      - name: Set lowercase image name
        run: echo "IMAGE_NAME=ghcr.io/${GITHUB_REPOSITORY_OWNER,,}/blockbench-mcp-pterodactyl" >> "$GITHUB_ENV"
```

- [ ] Remove the top-level `env.IMAGE_NAME` expression that preserves uppercase owner casing.

- [ ] Validate YAML by reading the file and checking indentation around the new step.

### Task 2: Harden startup script

**Files:**
- Modify: `docker/start-blockbench-mcp.sh`

**Interfaces:**
- Consumes: `SERVER_PORT`, `NOVNC_PORT`, `MCP_PORT`, `MCP_ENDPOINT`, `VNC_PASSWORD`, `DISPLAY_WIDTH`, and `DISPLAY_HEIGHT` environment variables.
- Produces: noVNC listener on `NOVNC_PORT`, a VNC auth file at `$HOME/.vnc/passwd`, and a clear first-run instruction file.

- [ ] Replace `x11vnc -passwd "$VNC_PASSWORD"` with:

```bash
VNC_PASSWORD_FILE="$HOME/.vnc/passwd"
rm -f "$VNC_PASSWORD_FILE"
x11vnc -storepasswd "$VNC_PASSWORD" "$VNC_PASSWORD_FILE" >/dev/null 2>&1
chmod 600 "$VNC_PASSWORD_FILE"
unset VNC_PASSWORD
```

- [ ] Start x11vnc with `-rfbauth "$VNC_PASSWORD_FILE"` instead of `-passwd`.

- [ ] Change the Pterodactyl readiness line to `echo "noVNC ready"`.

- [ ] Launch Blockbench with `dbus-run-session -- blockbench --no-sandbox` when `dbus-run-session` exists, otherwise fallback to `blockbench --no-sandbox`.

- [ ] Update generated first-run text to state that MCP port and endpoint variables are expected/manual settings and do not automatically rewrite Blockbench settings.

- [ ] Validate with `bash -n docker/start-blockbench-mcp.sh`.

### Task 3: Make Docker build more controllable

**Files:**
- Modify: `docker/Dockerfile`

**Interfaces:**
- Consumes: optional build args `BLOCKBENCH_DEB_URL` and `MCP_PLUGIN_URL`.
- Produces: Docker image that can either fetch the latest Blockbench release by default or use a pinned `.deb` URL.

- [ ] Add:

```dockerfile
ARG BLOCKBENCH_DEB_URL=""
ARG MCP_PLUGIN_URL="https://jasonjgardner.github.io/blockbench-mcp-plugin/mcp.js"
```

- [ ] Use `BLOCKBENCH_DEB_URL` when provided; otherwise keep the latest GitHub release lookup.

- [ ] Replace the hardcoded plugin URL with `$MCP_PLUGIN_URL`.

- [ ] Remove unused `openbox` package because the startup script uses Fluxbox.

### Task 4: Update egg JSON

**Files:**
- Modify: `pterodactyl/egg-blockbench-mcp-novnc.json`

**Interfaces:**
- Consumes: Docker image `ghcr.io/pastahimself/blockbench-mcp-pterodactyl:latest`.
- Produces: Pterodactyl egg whose readiness marker is `noVNC ready`.

- [ ] Change startup detection to:

```json
{
  "done": "noVNC ready"
}
```

- [ ] Update MCP variable descriptions to say they are manual/expected Blockbench settings, not automatic plugin configuration.

- [ ] Set `VNC Password` to `user_viewable: false` and `user_editable: true`.

- [ ] Update install instructions to explain that MCP exists only after loading the plugin in Blockbench.

- [ ] Validate with `python3 -m json.tool pterodactyl/egg-blockbench-mcp-novnc.json`.

### Task 5: Update README and rebuild artifacts

**Files:**
- Modify: `README.md`
- Copy: `pterodactyl/egg-blockbench-mcp-novnc.json` to `/mnt/data/egg-blockbench-mcp-novnc.json`
- Create: `/mnt/data/blockbench-mcp-pterodactyl-package.zip`

**Interfaces:**
- Consumes: fixed package files.
- Produces: downloadable ZIP and standalone egg JSON.

- [ ] Document three MCP access modes: same container/VPS network, SSH tunnel/Tailscale/VPN, or a secondary Pterodactyl allocation.

- [ ] Document that noVNC readiness is not MCP readiness.

- [ ] Rebuild the ZIP from the package directory.

- [ ] Validate ZIP contents with `unzip -l /mnt/data/blockbench-mcp-pterodactyl-package.zip`.
